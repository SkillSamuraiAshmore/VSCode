import turtle

turtle.bgcolor("black")

player = turtle.Turtle()
player.shape("square")
player.color("red")

turtle.done()